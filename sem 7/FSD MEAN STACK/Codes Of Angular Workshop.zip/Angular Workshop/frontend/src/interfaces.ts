interface IProduct{
    pid:number,
    pname:string,
    stockAvailable:boolean
}

var ob:IProduct = {
    pid:10,
    pname:"Fan",
    stockAvailable:true
}

console.log("ob");
console.log(ob);


interface IGoods{
    readonly gname:string,
    gcost:number,
    gdemand?:string
}

let ob2:IGoods = {
    gname:'Cooler',
    gcost:1000
}

console.log("ob2");
console.log(ob2);

// ob2.gname = 'AC'; throws error readonly

ob2.gcost = 9000;

console.log("ob2 after modifications");
console.log(ob2);

