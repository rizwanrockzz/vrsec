var ob = {
    pid: 10,
    pname: "Fan",
    stockAvailable: true
};
console.log("ob");
console.log(ob);
var ob2 = {
    gname: 'Cooler',
    gcost: 1000
};
console.log("ob2");
console.log(ob2);
// ob2.gname = 'AC'; throws error readonly
ob2.gcost = 9000;
console.log("ob2 after modifications");
console.log(ob2);
