var x:number|string;

x = 10;
console.log(x);

x="rizwan";
console.log(x); 

var arr:number[] = [7,1,3,14,12,9];

arr.push(49);
arr.push(52);
arr.push(28);
console.log(arr);

console.log("arr.pop()");
console.log(arr.pop());
console.log("arr.length");
console.log(arr.length);

console.log("arr");
console.log(arr);
console.log("arr.splice(0,2);");
arr.splice(0,2);
console.log(arr);



console.log(arr);
