class FirstClass{
    name:string;
    id:number;

    constructor(name: string,id: number){
        this.name = name;
        this.id = id;
    }

    getData():void {
        console.log(this.name);
        console.log(this.id);
    }
}

class SecondClass extends FirstClass{
    
}

var myobj = new FirstClass('rizwan',99);
myobj.getData();

