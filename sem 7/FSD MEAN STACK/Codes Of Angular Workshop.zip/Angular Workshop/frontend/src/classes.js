var FirstClass = /** @class */ (function () {
    function FirstClass(name, id) {
        this.name = name;
        this.id = id;
    }
    FirstClass.prototype.getData = function () {
        console.log(this.name);
        console.log(this.id);
    };
    return FirstClass;
}());
var myobj = new FirstClass('rizwan', 99);
myobj.getData();
