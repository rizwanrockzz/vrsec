const mainsec = document.getElementById("main-sec-with-categories");

console.log(mainsec);

async function getApiData() {
    const categories = await fetch('https://fakestoreapi.com/products/categories').then(res => res.json());

    let reqhtml = '';

    for (const category of categories) {
        reqhtml += `<div class="category-heading">
            <h1>${category}</h1>
            </div><div class="main-container" id="products-section">`;

        const datafromapi = await fetch(`https://fakestoreapi.com/products/category/${category}`).then(res => res.json());

        datafromapi.forEach(product => {
            reqhtml += `
                    
                    <div class="card">
                <img src="${product.image}" alt="Shoe">
                <p class="pname">${product.title}</p>
                <div class="rating">
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-half"></i>
                    <i class="bi bi-star"></i>
                </div>
            </div>`;
        });
        reqhtml +="</div>";
    }

    mainsec.innerHTML = reqhtml;
}

getApiData();
