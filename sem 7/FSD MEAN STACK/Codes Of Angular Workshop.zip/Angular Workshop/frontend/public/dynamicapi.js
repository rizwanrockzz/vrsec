const listdata = document.getElementById('dropdown-items-list');

console.log(listdata);


async function getApiDropDownData() {
    const categories = await fetch('https://fakestoreapi.com/products/categories').then(res => res.json());

    let listd = "";
    console.log(categories)
    categories.map((category) => {
        listd += `<option value="${category}">${category}</option>`
    })

    listdata.innerHTML = listd;
}

getApiDropDownData();

document.getElementById("dropdown-items-list").addEventListener("click", myOnChangeFunction);


async function myOnChangeFunction() {
    var selectedval = document.getElementById("dropdown-items-list").value;
    console.log("selectedval");
    console.log(selectedval);
    const mainsec = document.getElementById("main-sec-with-categories");

    console.log(mainsec);
    let reqhtml = "";
    const datafromapi = await fetch(`https://fakestoreapi.com/products/category/${selectedval}`).then(res => res.json());
    console.log("datafromapi");
    console.log(datafromapi);
    datafromapi.forEach((product) => {
        reqhtml += `
                <div class="card" key=${product.id}>
                    <img src="${product.image}" alt="Shoe">
                    <p class="pname">${product.title}</p>
                    <div class="bottom-sec">
                        <div class="rating">
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-fill"></i>
                            <i class="bi bi-star-half"></i>
                            <i class="bi bi-star"></i>
                        </div>
                        <div class="add-to-card" key=${product.id}>
                            <i class="bi bi-cart-plus"></i></div>
                        </div>
                    </div>
                </div>`;
    });
    console.log(reqhtml);
    mainsec.innerHTML = reqhtml;

}