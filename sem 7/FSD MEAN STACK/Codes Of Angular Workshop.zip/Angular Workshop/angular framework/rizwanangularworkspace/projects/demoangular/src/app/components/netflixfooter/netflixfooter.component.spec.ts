import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NetflixfooterComponent } from './netflixfooter.component';

describe('NetflixfooterComponent', () => {
  let component: NetflixfooterComponent;
  let fixture: ComponentFixture<NetflixfooterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NetflixfooterComponent]
    });
    fixture = TestBed.createComponent(NetflixfooterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
