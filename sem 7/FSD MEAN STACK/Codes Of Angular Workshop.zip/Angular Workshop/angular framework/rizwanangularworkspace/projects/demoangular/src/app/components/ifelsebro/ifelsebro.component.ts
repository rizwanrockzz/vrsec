import { Component } from '@angular/core';

@Component({
  selector: 'app-ifelsebro',
  templateUrl: './ifelsebro.component.html',
  styleUrls: ['./ifelsebro.component.css']
})
export class IfelsebroComponent {
  show = true;
  isVisible = false;
}
