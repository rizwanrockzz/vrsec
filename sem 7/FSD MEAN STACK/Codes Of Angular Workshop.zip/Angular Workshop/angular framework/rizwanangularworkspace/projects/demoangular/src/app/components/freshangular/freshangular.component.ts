import { Component } from '@angular/core';

@Component({
  selector: 'app-freshangular',
  templateUrl: './freshangular.component.html',
  styleUrls: ['./freshangular.component.css']
})
export class FreshangularComponent {

}
