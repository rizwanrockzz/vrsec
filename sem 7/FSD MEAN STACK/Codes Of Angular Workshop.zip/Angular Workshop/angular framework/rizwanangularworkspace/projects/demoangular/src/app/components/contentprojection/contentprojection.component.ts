import { Component } from '@angular/core';

@Component({
  selector: 'app-contentprojection',
  templateUrl: './contentprojection.component.html',
  styleUrls: ['./contentprojection.component.css']
})
export class ContentprojectionComponent {
  isVisible: boolean = true;
  isVisible2: boolean = false;
  value: number = 100;
}
