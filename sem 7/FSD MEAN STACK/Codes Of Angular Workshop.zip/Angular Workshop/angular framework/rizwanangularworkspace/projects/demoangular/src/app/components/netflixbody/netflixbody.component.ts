import { Component } from '@angular/core';

@Component({
  selector: 'app-netflixbody',
  templateUrl: './netflixbody.component.html',
  styleUrls: ['./netflixbody.component.css']
})
export class NetflixbodyComponent {

}
