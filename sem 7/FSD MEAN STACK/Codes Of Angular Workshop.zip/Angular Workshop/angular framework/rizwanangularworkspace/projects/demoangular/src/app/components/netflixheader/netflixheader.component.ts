import { Component } from '@angular/core';

@Component({
  selector: 'app-netflixheader',
  templateUrl: './netflixheader.component.html',
  styleUrls: ['./netflixheader.component.css']
})
export class NetflixheaderComponent {

}
