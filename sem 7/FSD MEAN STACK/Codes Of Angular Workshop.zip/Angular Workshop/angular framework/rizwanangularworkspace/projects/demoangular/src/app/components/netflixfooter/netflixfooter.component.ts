import { Component } from '@angular/core';

@Component({
  selector: 'app-netflixfooter',
  templateUrl: './netflixfooter.component.html',
  styleUrls: ['./netflixfooter.component.css']
})
export class NetflixfooterComponent {

}
