import { Component } from "@angular/core";

@Component({
    selector:'app-shop',
    templateUrl:'./shopping.component.html',
    styleUrls:['./shopping.component.css']
})

export class ShopComponent{}