import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NetflixbodyComponent } from './netflixbody.component';

describe('NetflixbodyComponent', () => {
  let component: NetflixbodyComponent;
  let fixture: ComponentFixture<NetflixbodyComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NetflixbodyComponent]
    });
    fixture = TestBed.createComponent(NetflixbodyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
