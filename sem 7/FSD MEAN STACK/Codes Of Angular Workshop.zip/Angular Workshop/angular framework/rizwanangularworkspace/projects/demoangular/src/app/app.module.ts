import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { ShopComponent } from './components/shopping/shopping.component';
import { LoginComponent } from './components/login/login.component';
import { RegistrationComponent } from './components/registration/registration.component';
import { FormsModule } from '@angular/forms';
import { ProductsComponent } from './components/products/products.component';
import { NetflixComponent } from './components/netflix/netflix.component';
import { NetflixheaderComponent } from './components/netflixheader/netflixheader.component';
import { NetflixbodyComponent } from './components/netflixbody/netflixbody.component';
import { NetflixfooterComponent } from './components/netflixfooter/netflixfooter.component';
import { NetflixregisterComponent } from './components/netflixregister/netflixregister.component';
import { IfelsebroComponent } from './components/ifelsebro/ifelsebro.component';
import { ContentprojectionComponent } from './components/contentprojection/contentprojection.component';
import { AttributesInAngularComponent } from './components/attributes-in-angular/attributes-in-angular.component';
import { FreshangularComponent } from './components/freshangular/freshangular.component';

@NgModule({
  declarations: [
    AppComponent,
    ShopComponent,
    LoginComponent,
    RegistrationComponent,
    ProductsComponent,
    NetflixComponent,
    NetflixheaderComponent,
    NetflixbodyComponent,
    NetflixfooterComponent,
    NetflixregisterComponent,
    IfelsebroComponent,
    ContentprojectionComponent,
    AttributesInAngularComponent,
    FreshangularComponent
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [FreshangularComponent]
  // bootstrap: [AttributesInAngularComponent]
  // bootstrap: [ContentprojectionComponent]
  // bootstrap: [IfelsebroComponent]
  // bootstrap: [NetflixComponent]
  // bootstrap: [RegistrationComponent]
  // bootstrap: [LoginComponent]
  // bootstrap: [ProductsComponent]
  // bootstrap: [AppComponent,
  //   ShopComponent,
  //   LoginComponent,
  //   RegistrationComponent,
  //   ProductsComponent, LoginComponent, RegistrationComponent, NetflixComponent, IfelsebroComponent, ContentprojectionComponent, AttributesInAngularComponent]
})
export class AppModule { }
