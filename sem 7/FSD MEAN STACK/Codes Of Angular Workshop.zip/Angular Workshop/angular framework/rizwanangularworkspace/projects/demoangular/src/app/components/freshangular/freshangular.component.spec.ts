import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FreshangularComponent } from './freshangular.component';

describe('FreshangularComponent', () => {
  let component: FreshangularComponent;
  let fixture: ComponentFixture<FreshangularComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FreshangularComponent]
    });
    fixture = TestBed.createComponent(FreshangularComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
