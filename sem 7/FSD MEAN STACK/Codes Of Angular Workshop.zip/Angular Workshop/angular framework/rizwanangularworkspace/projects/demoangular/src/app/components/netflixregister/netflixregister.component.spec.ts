import { ComponentFixture, TestBed } from '@angular/core/testing';

import { NetflixregisterComponent } from './netflixregister.component';

describe('NetflixregisterComponent', () => {
  let component: NetflixregisterComponent;
  let fixture: ComponentFixture<NetflixregisterComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [NetflixregisterComponent]
    });
    fixture = TestBed.createComponent(NetflixregisterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
