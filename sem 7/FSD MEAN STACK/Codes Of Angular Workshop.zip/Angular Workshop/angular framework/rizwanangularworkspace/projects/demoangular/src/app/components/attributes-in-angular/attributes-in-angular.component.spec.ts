import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AttributesInAngularComponent } from './attributes-in-angular.component';

describe('AttributesInAngularComponent', () => {
  let component: AttributesInAngularComponent;
  let fixture: ComponentFixture<AttributesInAngularComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AttributesInAngularComponent]
    });
    fixture = TestBed.createComponent(AttributesInAngularComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
