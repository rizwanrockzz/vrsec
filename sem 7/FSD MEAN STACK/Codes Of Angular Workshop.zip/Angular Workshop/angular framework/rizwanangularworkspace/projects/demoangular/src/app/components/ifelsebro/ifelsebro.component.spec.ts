import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IfelsebroComponent } from './ifelsebro.component';

describe('IfelsebroComponent', () => {
  let component: IfelsebroComponent;
  let fixture: ComponentFixture<IfelsebroComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IfelsebroComponent]
    });
    fixture = TestBed.createComponent(IfelsebroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
