// This file contains the renders of the router file
// Call Backs of routes are here
exports.add_user = (req, res) => {
  res.send("add-user");
};
