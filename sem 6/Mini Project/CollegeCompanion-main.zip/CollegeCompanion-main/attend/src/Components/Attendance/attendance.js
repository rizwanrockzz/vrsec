import React from "react";

function Attendance() {
  return (
    <div>
      <h2>Welcome to Attendance Section</h2>
    </div>
  );
}

export default Attendance;
