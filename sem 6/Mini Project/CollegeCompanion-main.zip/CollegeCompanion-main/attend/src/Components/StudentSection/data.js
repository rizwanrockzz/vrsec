export const studentData = [
  {
    id: 1,
    subject: "DSA",
    attendance: 76.2,
  },
  {
    id: 2,
    subject: "DBMS",
    attendance: 56.9,
  },
  {
    id: 3,
    subject: "CN",
    attendance: 93.6,
  },
];
