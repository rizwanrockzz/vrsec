package browserinitiation;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FirefoxInitiation {

	public static void main(String[] args) {
			System.setProperty("webdriver.gecko.driver", "C:\\Users\\Admin\\Downloads\\geckodriver-v0.32.2-win32\\geckodriver.exe");
			WebDriver driver= new FirefoxDriver();
			driver.get("https://www.vrsiddhartha.ac.in");
			driver.manage().window().maximize();

	}

}
