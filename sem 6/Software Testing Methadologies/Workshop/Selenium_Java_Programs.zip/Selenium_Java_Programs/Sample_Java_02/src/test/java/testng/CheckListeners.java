package testng;

import org.testng.Assert;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
@Listeners(testng.Listener.class)
public class CheckListeners {
	@Test
	public void pass()
	{
		Assert.assertTrue(true);
	}
	
	@Test
	public void fail()
	{
		Assert.assertTrue(false);
	}
	

}
