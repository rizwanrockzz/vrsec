
import java.io.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class ShopServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        HttpSession session;
        String pcode, qty, btnClick, code;

        try (PrintWriter pw = res.getWriter()) {
            pcode = req.getParameter("pcode");
            qty = req.getParameter("qty");
            btnClick = req.getParameter("submit");
            session = req.getSession(true);

            if (btnClick.equals("add item")) {
//                pw.println("Added Item");
                if (!(pcode.equals("") || qty.equals(""))) {
                    session.setAttribute(pcode, qty);
                    res.sendRedirect("/JavaSession/index.html");
                }
            } else if (btnClick.equals("remove item")) {
                session.removeAttribute(pcode);
                res.sendRedirect("/JavaSession/index.html");
            } else if (btnClick.equals("show item")) {
                Enumeration e = session.getAttributeNames();
                if (e.hasMoreElements()) {
                    pw.println("<h2>Your Shopping Cart Items</h2>");
                    while (e.hasMoreElements()) {
                        code = (String) e.nextElement();
                        pw.println("<p>Product Code is : " + code + "</p>\n"
                                + "    <p>Quantity is : " + session.getAttribute(code) + "</p><br>");
                    }
                } else {
                    pw.println("<h2>No Items In Your Cart</h2>");
                }
            } else if (btnClick.equals("pay item")) {
                pw.println("<h3>Thank you for buying " + pcode + "</h3>");

            } else if (btnClick.equals("logout")) {
                session.invalidate();
                res.sendRedirect("/JavaSession/index.html");
            }
            pw.close();
        } catch (Exception e) {
            System.out.print(e);
        }

    }
}
